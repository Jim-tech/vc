#!/bin/sh

echo "kill gpsagent"
killall gpsagent

gpsver=`./gpsversion | grep "gps firmware version"`
if [ "" != "$gpsver" ];then
	gpsver=`echo $gpsver | awk -F ':' '{print $2}'`
	echo "current gps version is:$gpsver"
fi

echo "start gps firmware upgrading..."
./gpsupdate $1

echo ""

gpsver=`./gpsversion | grep "gps firmware version"`
if [ "" != "$gpsver" ];then
	gpsver=`echo $gpsver | awk -F ':' '{print $2}'`
	echo "current gps version is:$gpsver"
fi

echo "startting gpsagent..."
/etc/init.d/gpsagent start

